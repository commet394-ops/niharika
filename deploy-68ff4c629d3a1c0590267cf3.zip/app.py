from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import os
from pathlib import Path
import glob
import json
import re
import uuid
from werkzeug.utils import secure_filename

ROOT = Path(__file__).parent.resolve()

app = Flask(__name__, static_folder=str(ROOT), static_url_path='')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change-me-for-prod')

# Simple admin password. For local use you can set ADMIN_PASSWORD env var.
# Default password set per user request. For production, set the ADMIN_PASSWORD
# environment variable instead of hardcoding.
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'Niha@art')

# Data and uploads
DATA_DIR = ROOT.joinpath('data')
DATA_DIR.mkdir(exist_ok=True)
UPLOADS = ROOT.joinpath('uploads')
UPLOADS.mkdir(exist_ok=True)

ALLOWED_EXT = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'}


def login_required(fn):
    from functools import wraps

    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)

    return wrapper


@app.route('/')
def index():
    # Serve index.html but inject (replace) embedded site/pages JSON
    index_path = ROOT.joinpath('index.html')
    if not index_path.exists():
        return 'index.html not found', 404

    html = index_path.read_text(encoding='utf-8')

    # Replace pages JSON
    pages_file = DATA_DIR.joinpath('pages.json')
    try:
        if pages_file.exists():
            pages_json = json.dumps(json.load(open(pages_file, 'r', encoding='utf-8')), ensure_ascii=False)
            html = re.sub(r"pages\.actions\.init\.serverPages\(\s*[\s\S]*?\)\s*;?",
                          f"pages.actions.init.serverPages({pages_json});",
                          html, flags=re.MULTILINE)
    except Exception:
        # on error, leave html unchanged
        pass

    # Replace site JSON
    site_file = DATA_DIR.joinpath('site.json')
    try:
        if site_file.exists():
            site_json = json.dumps(json.load(open(site_file, 'r', encoding='utf-8')), ensure_ascii=False)
            html = re.sub(r"site\.actions\.init\.site\(\s*[\s\S]*?\)\s*;?",
                          f"site.actions.init.site({site_json});",
                          html, flags=re.MULTILINE)
    except Exception:
        pass

    return html


@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        pwd = request.form.get('password', '')
        if pwd == ADMIN_PASSWORD:
            session['logged_in'] = True
            flash('Logged in', 'success')
            next_url = request.args.get('next') or url_for('admin')
            return redirect(next_url)
        flash('Invalid password', 'danger')
    return render_template('login.html')


@app.route('/admin/logout')
def logout():
    session.pop('logged_in', None)
    flash('Logged out', 'info')
    return redirect(url_for('login'))


@app.route('/admin')
@login_required
def admin():
    # list editable HTML files in the project root
    files = []
    for p in sorted(ROOT.glob('*.html')):
        files.append({
            'name': p.name,
            'size': p.stat().st_size,
            'mtime': p.stat().st_mtime,
        })
    # also show whether JSON files exist
    site_exists = DATA_DIR.joinpath('site.json').exists()
    pages_exists = DATA_DIR.joinpath('pages.json').exists()
    return render_template('admin.html', files=files, site_exists=site_exists, pages_exists=pages_exists)


def load_pages():
    path = DATA_DIR.joinpath('pages.json')
    if not path.exists():
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def save_pages(pages):
    path = DATA_DIR.joinpath('pages.json')
    # backup
    try:
        if path.exists():
            bak = DATA_DIR.joinpath(f"pages.json.bak.{int(os.path.getmtime(path))}")
            path.replace(bak)
    except Exception:
        pass
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(pages, f, ensure_ascii=False, indent=2)


def find_element_by_guid(page: dict, guid: str):
    # search in Sections -> ElementsTop, ElementsFixed, ElementsBottom, Columns
    for sec in page.get('Sections', []) or []:
        # ElementsTop
        for area in ('ElementsTop', 'ElementsFixed', 'ElementsBottom'):
            for el in sec.get(area, []) if isinstance(sec.get(area, []), list) else []:
                if el.get('Guid') == guid:
                    return el
                # nested columns
                if el.get('View') == 'columns-view':
                    for col in el.get('Columns', []) or []:
                        for cel in col.get('Elements', []) or []:
                            if cel.get('Guid') == guid:
                                return cel
        # ElementsFixed can have nested Content items (like gallery Content array)
        fixed = sec.get('ElementsFixed') or {}
        for k, v in (fixed.items() if isinstance(fixed, dict) else []):
            if isinstance(v, dict):
                for item in v.get('Content', []) if isinstance(v.get('Content', []), list) else []:
                    if item.get('Guid') == guid:
                        return item
    return None


@app.route('/admin/pages')
@login_required
def pages_list():
    pages = load_pages()
    return render_template('pages_list.html', pages=pages)


@app.route('/admin/pages/edit', methods=['GET', 'POST'])
@login_required
def page_edit():
    guid = request.values.get('guid')
    if not guid:
        flash('Missing page guid', 'danger')
        return redirect(url_for('pages_list'))

    pages = load_pages()
    page = None
    for p in pages:
        if p.get('Guid') == guid:
            page = p
            break
    if page is None:
        flash('Page not found', 'danger')
        return redirect(url_for('pages_list'))

    if request.method == 'POST':
        # Update simple page fields
        page['Title'] = request.form.get('title', page.get('Title'))
        page['Url'] = request.form.get('url', page.get('Url'))
        page['ShareImage'] = request.form.get('shareimage', page.get('ShareImage'))

        # Update element textual contents
        for key, val in request.form.items():
            if key.startswith('content_'):
                eguid = key.split('_', 1)[1]
                el = find_element_by_guid(page, eguid)
                if el is not None:
                    # set Content: if Content is dict, try to set appropriate key, else set string
                    if isinstance(el.get('Content'), dict):
                        # most text elements store string directly; if dict, set 'Content' key
                        el['Content'] = val
                    else:
                        el['Content'] = val

        # Handle file uploads
        for fname, fileobj in request.files.items():
            if not fileobj.filename:
                continue
            if fname.startswith('file_'):
                eguid = fname.split('_', 1)[1]
                ext = Path(fileobj.filename).suffix.lower()
                if ext not in ALLOWED_EXT:
                    flash(f'Invalid file type for {fileobj.filename}', 'danger')
                    continue
                new_name = f"{uuid.uuid4().hex}{ext}"
                target = UPLOADS.joinpath(new_name)
                fileobj.save(str(target))
                # update element src
                el = find_element_by_guid(page, eguid)
                if el is not None:
                    c = el.get('Content') or {}
                    if isinstance(c, dict):
                        c['Src'] = url_for('uploaded_file', filename=new_name, _external=False)
                        el['Content'] = c
                    else:
                        # replace string with dict
                        el['Content'] = {'Src': url_for('uploaded_file', filename=new_name, _external=False)}

        # save pages
        save_pages(pages)
        flash('Page saved', 'success')
        return redirect(url_for('pages_list'))

    return render_template('page_edit.html', page=page)


def safe_path(filename: str) -> Path:
    # prevent path traversal - only allow files in project root
    name = os.path.basename(filename)
    return ROOT.joinpath(name)


@app.route('/admin/edit', methods=['GET', 'POST'])
@login_required
def edit():
    filename = request.values.get('file')
    if not filename:
        flash('Missing file parameter', 'danger')
        return redirect(url_for('admin'))

    path = safe_path(filename)
    if not path.exists() or path.suffix.lower() != '.html':
        flash('File not found or not editable', 'danger')
        return redirect(url_for('admin'))

    if request.method == 'POST':
        content = request.form.get('content', '')
        # write file
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        flash(f'Saved {filename}', 'success')
        return redirect(url_for('admin'))

    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    return render_template('edit.html', filename=filename, content=content)


@app.route('/admin/editjson', methods=['GET'])
@login_required
def editjson():
    which = request.args.get('which')
    if which not in ('site', 'pages'):
        flash('Invalid json target', 'danger')
        return redirect(url_for('admin'))
    path = DATA_DIR.joinpath(f'{which}.json')
    if not path.exists():
        # create empty
        path.write_text('[]' if which == 'pages' else '{}', encoding='utf-8')
    content = path.read_text(encoding='utf-8')
    return render_template('content_edit.html', which=which, content=content)


@app.route('/admin/savejson', methods=['POST'])
@login_required
def savejson():
    which = request.form.get('which')
    content = request.form.get('content', '')
    if which not in ('site', 'pages'):
        flash('Invalid target', 'danger')
        return redirect(url_for('admin'))
    path = DATA_DIR.joinpath(f'{which}.json')
    # validate JSON
    try:
        parsed = json.loads(content)
    except Exception as e:
        flash(f'Invalid JSON: {e}', 'danger')
        return redirect(url_for('editjson') + f'?which={which}')
    path.write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding='utf-8')
    flash(f'Saved {which}.json', 'success')
    return redirect(url_for('admin'))


@app.route('/admin/upload', methods=['POST'])
@login_required
def upload():
    f = request.files.get('file')
    if not f:
        flash('No file uploaded', 'danger')
        return redirect(request.referrer or url_for('admin'))
    filename = secure_filename(f.filename)
    if not filename:
        flash('Invalid filename', 'danger')
        return redirect(request.referrer or url_for('admin'))
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        flash('File type not allowed', 'danger')
        return redirect(request.referrer or url_for('admin'))
    new_name = f"{uuid.uuid4().hex}{ext}"
    target = UPLOADS.joinpath(new_name)
    f.save(str(target))
    url = url_for('uploaded_file', filename=new_name, _external=False)
    flash(f'Uploaded: {url}', 'success')
    return redirect(request.referrer or url_for('admin'))


@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(str(UPLOADS), filename)


@app.route('/admin/delete', methods=['POST'])
@login_required
def delete():
    filename = request.form.get('file')
    if not filename:
        flash('Missing file parameter', 'danger')
        return redirect(url_for('admin'))
    path = safe_path(filename)
    if not path.exists():
        flash('File does not exist', 'danger')
        return redirect(url_for('admin'))
    # delete file
    try:
        path.unlink()
        flash(f'Deleted {filename}', 'success')
    except Exception as e:
        flash(f'Error deleting {filename}: {e}', 'danger')
    return redirect(url_for('admin'))


@app.route('/admin/media')
@login_required
def media_browser():
    # list uploaded files with URLs and basic metadata
    files = []
    for p in sorted(UPLOADS.glob('*.*')):
        if p.suffix.lower() in ALLOWED_EXT:
            files.append({
                'name': p.name,
                'size': p.stat().st_size,
                'mtime': p.stat().st_mtime,
                'url': url_for('uploaded_file', filename=p.name),
                'is_image': p.suffix.lower() in {'.jpg', '.jpeg', '.png', '.gif', '.webp'},
            })
    return render_template('media_browser.html', files=files)


if __name__ == '__main__':
    # Run on port 5000. Use env var PORT to override.
    port = int(os.environ.get('PORT', '5000'))
    app.run(host='0.0.0.0', port=port, debug=True)
